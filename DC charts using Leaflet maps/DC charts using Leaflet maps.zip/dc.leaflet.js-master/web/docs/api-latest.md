# dc.leaflet.js API

#### .r([bubbleRadiusScale])
Get or set bubble radius scale. By default bubble chart uses ```d3.scale.linear().domain([0, 100])``` as its r scale .
var dc_leaflet = {
    version: '<%= conf.pkg.version %>'
};
